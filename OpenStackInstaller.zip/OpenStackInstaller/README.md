OSinstall.sh
A simple OpenStack installer that allows you to install OpenStack either interactively by specifying options on the command line or automated as part of a bigger installation.
Originally written to help get a test environment installed under VirtualBox

Now updated for Essex on Precise and not limited to a virtual environment!

Kevin Jackson <kevin@linuxservices.co.uk> https://twitter.com/#!/itarchitectkev | irc.freenode.org uksysadmin
